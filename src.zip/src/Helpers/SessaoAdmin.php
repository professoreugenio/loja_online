<?php

declare(strict_types=1);

namespace App\Helpers;

final class SessaoAdmin
{
    private const CHAVE_SESSAO = 'usuario_admin';

    private function __construct() {}

    public static function entrar(
        array $usuario
    ): void {

        if (
            !isset(
                $usuario['id'],
                $usuario['nome'],
                $usuario['email'],
                $usuario['nivel_admin']
            )
        ) {
            throw new \InvalidArgumentException(
                'Dados do usuário administrativo incompletos.'
            );
        }

        session_regenerate_id(true);

        $_SESSION[self::CHAVE_SESSAO] = [
            'id' =>
            (int) $usuario['id'],

            'nome' =>
            (string) $usuario['nome'],

            'email' =>
            (string) $usuario['email'],

            'nivel_admin' =>
            strtolower(
                trim(
                    (string)
                    $usuario['nivel_admin']
                )
            ),

            'autenticado_em' =>
            time(),
        ];
    }


    public static function id(): ?int
    {
        $id = $_SESSION['usuario_admin']['id'] ?? null;

        return is_numeric($id)
            ? (int) $id
            : null;
    }


    


    public static function nivel(): ?string
    {
        $nivel =
            self::dados()['nivel_admin']
            ?? null;

        if (!is_string($nivel)) {
            return null;
        }

        $nivel = strtolower(
            trim($nivel)
        );

        return in_array(
            $nivel,
            ['master', 'operador'],
            true
        )
            ? $nivel
            : null;
    }
        public static function ehMaster(): bool
    {
        return (
            $_SESSION['usuario_admin']['nivel_admin']
            ?? ''
        ) === 'master';
    }

    public static function exigirMaster(): void
    {
        self::exigirLogin();

        if (self::ehMaster()) {
            return;
        }

        http_response_code(403);

        exit('Acesso permitido somente '
            . 'para administrador Master.');
    }

    public static function atualizarPerfil(
        string $nome,
        string $email
    ): void {
        if (!self::autenticado()) {
            return;
        }

        $_SESSION['usuario_admin']['nome'] = $nome;

        $_SESSION['usuario_admin']['email'] = $email;
    }

    public static function autenticado(): bool
    {
        return !empty($_SESSION[self::CHAVE_SESSAO]['id']);
    }

    public static function dados(): array
    {
        $dados = $_SESSION[self::CHAVE_SESSAO]
            ?? [];

        return is_array($dados)
            ? $dados
            : [];
    }



    public static function nome(): ?string
    {
        $nome = self::dados()['nome'] ?? null;

        return is_string($nome)
            && $nome !== ''
            ? $nome
            : null;
    }

    public static function exigirLogin(): void
    {
        if (self::autenticado()) {
            return;
        }

        $base = defined('BASE_URL')
            ? rtrim((string) BASE_URL, '/')
            : '';

        header(
            'Location: '
                . $base
                . '/loginadmin'
        );

        exit;
    }

    public static function sair(): void
    {
        $_SESSION = [];

        if (
            session_status()
            === PHP_SESSION_ACTIVE
            && ini_get('session.use_cookies')
        ) {
            $parametros =
                session_get_cookie_params();

            setcookie(
                session_name(),
                '',
                [
                    'expires' =>
                    time() - 42000,

                    'path' =>
                    $parametros['path']
                        ?: '/',

                    'domain' =>
                    $parametros['domain']
                        ?: '',

                    'secure' =>
                    (bool)
                    $parametros['secure'],

                    'httponly' =>
                    (bool)
                    $parametros['httponly'],

                    'samesite' =>
                    'Lax',
                ]
            );
        }

        if (
            session_status()
            === PHP_SESSION_ACTIVE
        ) {
            session_destroy();
        }
    }
}
