<?php

declare(strict_types=1);

use App\Helpers\View;

$baseUrl = defined('BASE_URL') ? BASE_URL : '';

?>
<!doctype html>
<html lang="pt-BR">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard Administrativo | Loja Online</title>
    <meta name="description" content="Painel administrativo para gerenciamento da loja online.">

    <!-- Caminho-base do projeto no XAMPP -->
    <base href="<?= BASE_URL ?>/">

    <link rel="icon" href="assets/img/favicon.ico">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css" rel="stylesheet">


    <link rel="stylesheet" href="<?= htmlspecialchars($baseUrl . '/assets/css/admin.css', ENT_QUOTES, 'UTF-8') ?>">
</head>

<body>
    <?php View::componenteAdmin('aside'); ?>

    <div class="offcanvas offcanvas-start offcanvas-dashboard" tabindex="-1" id="menuMobile">
        <div class="offcanvas-header border-bottom border-secondary">
            <div>
                <h2 class="offcanvas-title h5 mb-0">Loja Online</h2>
                <small class="text-white-50">Painel administrativo</small>
            </div>
            <button class="btn-close" type="button" data-bs-dismiss="offcanvas" aria-label="Fechar menu"></button>
        </div>

        <div class="offcanvas-body">
            <nav class="sidebar-nav p-0" aria-label="Menu móvel">
                <a class="sidebar-link active" href="admin"><i class="bi bi-grid-1x2-fill"></i> Dashboard</a>
                <a class="sidebar-link" href="admin/produtos"><i class="bi bi-box-seam-fill"></i> Produtos</a>
                <a class="sidebar-link" href="admin/categorias"><i class="bi bi-tags-fill"></i> Categorias</a>
                <a class="sidebar-link" href="admin/clientes"><i class="bi bi-people-fill"></i> Clientes</a>
                <a class="sidebar-link" href="admin/pedidos"><i class="bi bi-bag-check-fill"></i> Pedidos</a>
                <a class="sidebar-link" href="admin/pagamentos"><i class="bi bi-credit-card-fill"></i> Pagamentos</a>
                <a class="sidebar-link" href="admin/estoque"><i class="bi bi-boxes"></i> Estoque</a>
                <a class="sidebar-link" href="admin/notificacoes"><i class="bi bi-bell-fill"></i> Notificações</a>
                <a class="sidebar-link" href="admin/relatorios"><i class="bi bi-bar-chart-line-fill"></i> Relatórios</a>
                <a class="sidebar-link" href="admin/configuracoes"><i class="bi bi-gear-fill"></i> Configurações</a>
            </nav>
        </div>
    </div>

    <div class="main-wrapper">
        <?php View::componenteAdmin('header'); ?>

        <main class="content-area">
            <div class="container-fluid p-0">
                <section class="mb-4">


                    <div
                        class="d-flex
               justify-content-between
               align-items-center
               flex-wrap
               gap-3
               mb-4">

                        <div>

                            <h1 class="h3 fw-bold mb-1">
                                Estoque
                            </h1>

                            <p class="text-secondary mb-0">
                                Acompanhe a quantidade disponível
                                e os limites mínimos dos produtos.
                            </p>

                        </div>

                    </div>


                    <?php if (!empty($sucesso)): ?>

                        <div
                            class="alert
                   alert-success
                   alert-dismissible
                   fade show">

                            <?=
                            htmlspecialchars(
                                $sucesso,
                                ENT_QUOTES,
                                'UTF-8'
                            )
                            ?>

                            <button
                                type="button"
                                class="btn-close"
                                data-bs-dismiss="alert"></button>

                        </div>

                    <?php endif; ?>


                    <?php if (!empty($erro)): ?>

                        <div
                            class="alert alert-danger">

                            <?=
                            htmlspecialchars(
                                $erro,
                                ENT_QUOTES,
                                'UTF-8'
                            )
                            ?>

                        </div>

                    <?php endif; ?>


                    <!-- INDICADORES -->

                    <div class="row g-3 mb-4">


                        <div
                            class="col-12
                   col-sm-6
                   col-xl-3">

                            <div
                                class="card
                       border-0
                       shadow-sm
                       h-100">

                                <div class="card-body">

                                    <small class="text-secondary">
                                        Produtos
                                    </small>

                                    <div
                                        class="fs-3 fw-bold">

                                        <?=
                                        (int) (
                                            $indicadores['total_produtos']
                                            ?? 0
                                        )
                                        ?>

                                    </div>

                                </div>

                            </div>

                        </div>


                        <div
                            class="col-12
                   col-sm-6
                   col-xl-3">

                            <div
                                class="card
                       border-0
                       shadow-sm
                       h-100">

                                <div class="card-body">

                                    <small class="text-secondary">
                                        Unidades em estoque
                                    </small>

                                    <div
                                        class="fs-3 fw-bold">

                                        <?=
                                        (int) (
                                            $indicadores['total_unidades']
                                            ?? 0
                                        )
                                        ?>

                                    </div>

                                </div>

                            </div>

                        </div>


                        <div
                            class="col-12
                   col-sm-6
                   col-xl-3">

                            <a
                                href="<?=
                                        BASE_URL
                                        ?>/admin/estoque?filtro=baixo"
                                class="text-decoration-none">

                                <div
                                    class="card
                           border-warning
                           shadow-sm
                           h-100">

                                    <div class="card-body">

                                        <small
                                            class="text-warning">
                                            Estoque baixo
                                        </small>

                                        <div
                                            class="fs-3
                                   fw-bold
                                   text-dark">

                                            <?=
                                            (int) (
                                                $indicadores['baixos']
                                                ?? 0
                                            )
                                            ?>

                                        </div>

                                    </div>

                                </div>

                            </a>

                        </div>


                        <div
                            class="col-12
                   col-sm-6
                   col-xl-3">

                            <a
                                href="<?=
                                        BASE_URL
                                        ?>/admin/estoque?filtro=zerado"
                                class="text-decoration-none">

                                <div
                                    class="card
                           border-danger
                           shadow-sm
                           h-100">

                                    <div class="card-body">

                                        <small class="text-danger">
                                            Estoque zerado
                                        </small>

                                        <div
                                            class="fs-3
                                   fw-bold
                                   text-dark">

                                            <?=
                                            (int) (
                                                $indicadores['zerados']
                                                ?? 0
                                            )
                                            ?>

                                        </div>

                                    </div>

                                </div>

                            </a>

                        </div>

                    </div>


                    <!-- FILTROS -->

                    <div
                        class="card
               border-0
               shadow-sm
               mb-4">

                        <div class="card-body">

                            <form
                                method="get"
                                action="<?=
                                        BASE_URL
                                        ?>/admin/estoque">

                                <div
                                    class="row
                           g-3
                           align-items-end">


                                    <div class="col-md-6">

                                        <label
                                            class="form-label">
                                            Produto
                                        </label>

                                        <input
                                            type="search"
                                            class="form-control"
                                            name="q"
                                            placeholder="Pesquisar produto"
                                            value="<?=
                                                    htmlspecialchars(
                                                        $filtros['q']
                                                            ?? '',
                                                        ENT_QUOTES,
                                                        'UTF-8'
                                                    )
                                                    ?>">

                                    </div>


                                    <div class="col-md-3">

                                        <label
                                            class="form-label">
                                            Situação
                                        </label>

                                        <select
                                            class="form-select"
                                            name="filtro">

                                            <option value="">
                                                Todos
                                            </option>


                                            <option
                                                value="baixo"
                                                <?=
                                                (
                                                    $filtros['filtro']
                                                    ?? ''
                                                ) === 'baixo'
                                                    ? 'selected'
                                                    : ''
                                                ?>>
                                                Estoque baixo
                                            </option>


                                            <option
                                                value="zerado"
                                                <?=
                                                (
                                                    $filtros['filtro']
                                                    ?? ''
                                                ) === 'zerado'
                                                    ? 'selected'
                                                    : ''
                                                ?>>
                                                Zerado
                                            </option>


                                            <option
                                                value="normal"
                                                <?=
                                                (
                                                    $filtros['filtro']
                                                    ?? ''
                                                ) === 'normal'
                                                    ? 'selected'
                                                    : ''
                                                ?>>
                                                Normal
                                            </option>

                                        </select>

                                    </div>


                                    <div class="col-md-3">

                                        <button
                                            class="btn
                                   btn-primary
                                   w-100"
                                            type="submit">

                                            <i
                                                class="bi
                                       bi-search
                                       me-1"></i>

                                            Filtrar

                                        </button>

                                    </div>

                                </div>

                            </form>

                        </div>

                    </div>


                    <!-- TABELA -->

                    <div
                        class="card
               border-0
               shadow-sm">

                        <div class="table-responsive">

                            <table
                                class="table
                       table-hover
                       align-middle
                       mb-0">

                                <thead class="table-light">

                                    <tr>
                                        <th>Produto</th>
                                        <th>Categoria</th>
                                        <th class="text-center">
                                            Estoque
                                        </th>
                                        <th class="text-center">
                                            Limite
                                        </th>
                                        <th>Situação</th>
                                        <th class="text-end">
                                            Ações
                                        </th>
                                    </tr>

                                </thead>


                                <tbody>


                                    <?php foreach (
                                        $produtos as $produto
                                    ): ?>


                                        <?php

                                        $estoque =
                                            (int)
                                            $produto['estoque'];

                                        $limite =
                                            (int)
                                            $produto['limite_estoque'];


                                        if ($estoque === 0) {

                                            $situacao =
                                                'Zerado';

                                            $classe =
                                                'text-bg-danger';
                                        } elseif (
                                            $estoque <= $limite
                                        ) {

                                            $situacao =
                                                'Baixo';

                                            $classe =
                                                'text-bg-warning';
                                        } else {

                                            $situacao =
                                                'Normal';

                                            $classe =
                                                'text-bg-success';
                                        }

                                        ?>


                                        <tr>


                                            <td>

                                                <div class="fw-semibold">

                                                    <?=
                                                    htmlspecialchars(
                                                        $produto['nome'],
                                                        ENT_QUOTES,
                                                        'UTF-8'
                                                    )
                                                    ?>

                                                </div>

                                            </td>


                                            <td>

                                                <?=
                                                htmlspecialchars(
                                                    $produto['categoria'],
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                )
                                                ?>

                                            </td>


                                            <td
                                                class="text-center
                                   fw-semibold">

                                                <?= $estoque ?>

                                            </td>


                                            <td style="width:180px">

                                                <form
                                                    method="post"
                                                    action="<?=
                                                            BASE_URL
                                                            ?>/admin/estoque/limite"
                                                    class="d-flex gap-2">

                                                    <input
                                                        type="hidden"
                                                        name="_token"
                                                        value="<?=
                                                                htmlspecialchars(
                                                                    $csrfToken,
                                                                    ENT_QUOTES,
                                                                    'UTF-8'
                                                                )
                                                                ?>">


                                                    <input
                                                        type="hidden"
                                                        name="id"
                                                        value="<?=
                                                                htmlspecialchars(
                                                                    $produto['id_seguro'],
                                                                    ENT_QUOTES,
                                                                    'UTF-8'
                                                                )
                                                                ?>">


                                                    <input
                                                        type="number"
                                                        class="form-control
                                           form-control-sm"
                                                        name="limite_estoque"
                                                        min="0"
                                                        value="<?=
                                                                $limite
                                                                ?>"
                                                        required>


                                                    <button
                                                        type="submit"
                                                        class="btn
                                           btn-outline-primary
                                           btn-sm"
                                                        title="Salvar limite">

                                                        <i
                                                            class="bi
                                               bi-check-lg"></i>

                                                    </button>

                                                </form>

                                            </td>


                                            <td>

                                                <span
                                                    class="badge
                                       <?=
                                        $classe
                                        ?>">

                                                    <?=
                                                    $situacao
                                                    ?>

                                                </span>

                                            </td>


                                            <td class="text-end">

                                                <a
                                                    href="<?=
                                                            BASE_URL
                                                            ?>/admin/produto/editar?id=<?=
                                                                                        rawurlencode(
                                                                                            $produto['id_seguro']
                                                                                        )
                                                                                        ?>"
                                                    class="btn
                                       btn-outline-secondary
                                       btn-sm">

                                                    <i
                                                        class="bi
                                           bi-pencil-square
                                           me-1"></i>

                                                    Editar

                                                </a>

                                            </td>


                                        </tr>


                                    <?php endforeach; ?>


                                    <?php if (
                                        $produtos === []
                                    ): ?>

                                        <tr>

                                            <td
                                                colspan="6"
                                                class="text-center
                                   py-5
                                   text-secondary">

                                                Nenhum produto encontrado.

                                            </td>

                                        </tr>

                                    <?php endif; ?>


                                </tbody>

                            </table>

                        </div>

                    </div>


                </section>




            </div>
        </main>

        <?php View::componenteAdmin('footer'); ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('anoAtual').textContent = new Date().getFullYear();

            const caminhoAtual = window.location.pathname
                .replace('<?= BASE_URL ?>/', '')
                .replace(/^\/+|\/+$/g, '');

            document.querySelectorAll('.sidebar-link[data-route]').forEach(function(link) {
                const rota = link.dataset.route || '';
                link.classList.remove('active');

                if (caminhoAtual === rota || caminhoAtual.startsWith(rota + '/')) {
                    link.classList.add('active');
                }
            });
        });
    </script>
</body>

</html>